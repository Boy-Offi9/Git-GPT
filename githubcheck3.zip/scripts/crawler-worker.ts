import { config } from "dotenv";
import { resolve } from "node:path";

config({ path: resolve(process.cwd(), ".env.local") });
config();

async function main() {
  if (!process.env.DATABASE_URL) {
    console.error("DATABASE_URL is required");
    process.exit(1);
  }
  if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
    console.error("SESSION_SECRET (>=32 chars) is required to decrypt crawler tokens");
    process.exit(1);
  }
  if (!process.env.GITHUB_CLIENT_ID || !process.env.GITHUB_CLIENT_SECRET) {
    console.error("GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET are required");
    process.exit(1);
  }

  const { runCrawlerWorkerLoop } = await import("@/lib/crawler/worker-loop");
  await runCrawlerWorkerLoop();
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
